#!/bin/bash
c++ StringRange.cpp -o StringRange
./StringRange
